<?php
$name=$_POST['product1'];
$model=$_POST['origin1'];
$os=$_POST['best_before_date1'];
$screensize=$_POST['amount1'];
$image=$_POST['image1'];
echo "Form Submitted Succesfully";
echo $name;
echo $origin;
echo $best;
echo $amount;
echo $image;
?>
