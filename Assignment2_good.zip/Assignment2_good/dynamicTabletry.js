
function generateTable()
{
	var jcontent = {
		"product" : "Granny smith apples",
		"product" : "Skyr naturel", 
		"product" : "Eat natural",
		"product" : "Maza hummus",
		"origin" : "Australia",
		"origin" : "Iceland", 
		"origin" : "Brittan", 
		"origin" : "Netherlands",
		"best_before_date" : "08-02-2021", 
		"best_before_date" : "22-03-2021", 
		"best_before_date" : "23-03-2021", 
		"best_before_date" : "02-02-2021",
		"amount" : '1KG', 
		"amount" : '450 grams', 
		"amount" : '3 x 50 grams', 
		"amount" : '200 grams',
		"image" : "https://cdn0.woolworths.media/content/wowproductimages/large/310966.jpg", 
		"image" : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfMKAbc785w9NdGU-emZ6eKk66IqlpVwlGAA&usqp=CAU", 
		"image" : "https://static.ah.nl/static/product/AHI_43545239353730373033_2_LowRes_JPG.JPG?options=399,q85", 
		"image" : "https://static.ah.nl/image-optimization/static/product/AHI_43545239363932383838_1_200x200_JPG.JPG?options=399,q85" 
		}
		
		$.get("https://wt.ops.labs.vu.nl/api21/3c20e1b6", jcontent, function(data){
			console.log("success"); 
			
		
		var items = [];
		$.each(data, function(key, val){
		items.push("<tr>");
		items.push("<td id=''"+key+"''>"+val.product+"</td>");
		items.push("<td id=''"+key+"''>"+val.origin+"</td>");
		items.push("<td id=''"+key+"''>"+val.best_before_date+"</td>");
		items.push("<td id=''"+key+"''>"+val.amount+"</td>");
		items.push("<td id=''"+key+"''>"+val.image+"</td>");
		items.push("</tr>");
		});

		$("<thead>", {html: items.join("")}).prependTo("table");
		
		}, "json");
		
}

    
   
$("#submit").click(function(){
	var product = $("product").val();
	var origin = $("origin").val();
	var best_before_date = $("best_before_date").val();
	var amount = $("amount").val();
	var image = $("image").val();
	var dataString = 'product1=' + product + '&origin1=' + origin + '&best_before_date1=' + best_before_date + '&amount1=' + amount + '&image1=' + image;
	$.ajax({
	type: "POST",
	url: "update.php",
	data: dataString,
	cache: false,
	success: function(result){
	$("#display").html(result);
	}
});		
});
	
	
	
	
	
	
	
	
